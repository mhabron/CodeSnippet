from django.apps import AppConfig


class WhsappConfig(AppConfig):
    name = 'whsapp'
